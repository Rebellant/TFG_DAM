<?php
class GodotGame
{
	private $host = 'localhost';
	private $user = 'admin';
	private $password = "Z0dMYpCjUg8P";
	private $database = "godot_game";

	public function dameConexion()
	{
		$conn = new mysqli($this->host, $this->user, $this->password, $this->database);
		$conn->set_charset("utf8mb4"); //Para evitar problemas con tildes, ñ y caracteres no estandar
		if ($conn->connect_error) {
			die("Error al conectar con MYSQL" . $conn->connect_error);
		} else {
			return $conn;
		}
	}
}
?>