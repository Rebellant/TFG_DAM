<?php
class Jugador
{
	private $tabla = "Jugador";
	public $id_jugador;
	public $nombre;
	private $conn;

	public function __construct($db)
	{
		$this->conn = $db;
	}

	function leer()
	{
		if ($this->id_jugador >= 0) {
			$stmt = $this->conn->prepare("
			SELECT * FROM " . $this->tabla . " WHERE id_jugador = ?");
			$stmt->bind_param("i", $this->id_jugador);
		} else { //Si no se le pasa id correcto hace un SELECT masivo
			$stmt = $this->conn->prepare("SELECT * FROM " . $this->tabla);
		}
		$stmt->execute();
		$result = $stmt->get_result();
		return $result;
	}

	function insertar()
	{
		$stmt = $this->conn->prepare("
		    INSERT INTO " . $this->tabla . "(`nombre`)
			VALUES(?)");

		$this->nombre = strip_tags($this->nombre);

		$stmt->bind_param("s", $this->nombre);
		if ($stmt->execute()) {
			return true;
		}
		return false;
	}

	function actualizar()
	{
		$stmt = $this->conn->prepare("
		    UPDATE " . $this->tabla . " 
			SET nombre = ? WHERE id_jugador = ?");

		$this->nombre = strip_tags($this->nombre);
		$this->id_jugador = strip_tags($this->id_jugador);
		$stmt->bind_param("si", $this->nombre, $this->id_jugador);

		if ($stmt->execute()) {
			return true;
		}

		return false;
	}

	function borrar()
	{
		$stmt = $this->conn->prepare("
			DELETE FROM " . $this->tabla . " 
			WHERE id_jugador = ?");

		$this->id_jugador = strip_tags($this->id_jugador);
		$stmt->bind_param("i", $this->id_jugador);
		if ($stmt->execute()) {
			return true;
		}

		return false;
	}
}
?>