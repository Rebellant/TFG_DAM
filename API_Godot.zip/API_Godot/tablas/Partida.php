<?php
class Partida
{
	private $tabla = "Partida";
	public $id_partida;
	public $id_jugador;
	public $fecha_creacion;
	public $fecha_guardado;
	private $conn;

	public function __construct($db)
	{
		$this->conn = $db;
	}

	function leer()
	{
		if ($this->id_partida >= 0) {
			$stmt = $this->conn->prepare("
			SELECT * FROM " . $this->tabla . " WHERE id_partida = ?");
			$stmt->bind_param("i", $this->id_partida);
		} else { //Si no se le pasa id correcto hace un SELECT masivo
			$stmt = $this->conn->prepare("SELECT * FROM " . $this->tabla);
		}
		$stmt->execute();
		$result = $stmt->get_result();
		return $result;
	}

	function leerPorJugador()
	{
		if ($this->id_jugador > 0) {
			$stmt = $this->conn->prepare("
			SELECT * FROM " . $this->tabla . " WHERE id_jugador = ?");
			$stmt->bind_param("i", $this->id_jugador);
		} else {
			$stmt = $this->conn->prepare("SELECT * FROM " . $this->tabla);
		}
		$stmt->execute();
		$result = $stmt->get_result();
		return $result;
	}

	function insertar()
	{
		$stmt = $this->conn->prepare("
		    INSERT INTO " . $this->tabla . "(`id_jugador`)
			VALUES(?)");

		$this->id_jugador = strip_tags($this->id_jugador);

		$stmt->bind_param("i", $this->id_jugador);
		if ($stmt->execute()) {
			return true;
		}
		return false;
	}

	function actualizar()
	{
		$stmt = $this->conn->prepare("
		    UPDATE " . $this->tabla . " 
			SET id_jugador = ? WHERE id_partida = ?");

		$this->id_jugador = strip_tags($this->id_jugador);
		$this->id_partida = strip_tags($this->id_partida);
		$stmt->bind_param("ii", $this->id_jugador, $this->id_partida);

		if ($stmt->execute()) {
			return true;
		}

		return false;
	}

	function borrar()
	{
		$stmt = $this->conn->prepare("
			DELETE FROM " . $this->tabla . " 
			WHERE id_partida = ?");

		$this->id_partida = strip_tags($this->id_partida);
		$stmt->bind_param("i", $this->id_partida);
		if ($stmt->execute()) {
			return true;
		}

		return false;
	}
}
?>