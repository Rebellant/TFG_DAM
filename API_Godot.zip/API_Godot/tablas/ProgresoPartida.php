<?php
class ProgresoPartida
{
	private $tabla = "Progreso_partida";
	public $id_progreso;
	public $id_partida;
	public $nivel_actual;
	public $checkpoint;
	public $monedas;
	public $enemigos_derrotados;
	public $jefe_derrotado;
	private $conn;

	public function __construct($db)
	{
		$this->conn = $db;
	}

	function leer()
	{
		if ($this->id_progreso >= 0) {
			$stmt = $this->conn->prepare("
			SELECT * FROM " . $this->tabla . " WHERE id_progreso = ?");
			$stmt->bind_param("i", $this->id_progreso);
		} else { //Si no se le pasa id correcto hace un SELECT masivo
			$stmt = $this->conn->prepare("SELECT * FROM " . $this->tabla);
		}
		$stmt->execute();
		$result = $stmt->get_result();
		return $result;
	}

	function leerPorPartida()
	{
		if ($this->id_partida > 0) {
			$stmt = $this->conn->prepare("
			SELECT * FROM " . $this->tabla . " WHERE id_partida = ?");
			$stmt->bind_param("i", $this->id_partida);
		} else {
			$stmt = $this->conn->prepare("SELECT * FROM " . $this->tabla);
		}
		$stmt->execute();
		$result = $stmt->get_result();
		return $result;
	}

	function insertar()
	{
		$stmt = $this->conn->prepare("
		    INSERT INTO " . $this->tabla . "(`id_partida`, `nivel_actual`, `checkpoint`, `monedas`, `enemigos_derrotados`, `jefe_derrotado`)
			VALUES(?,?,?,?,?,?)");

		$this->id_partida = strip_tags($this->id_partida);
		$this->nivel_actual = strip_tags($this->nivel_actual);
		$this->checkpoint = strip_tags($this->checkpoint);
		$this->monedas = strip_tags($this->monedas);
		$this->enemigos_derrotados = strip_tags($this->enemigos_derrotados);
		$this->jefe_derrotado = strip_tags($this->jefe_derrotado);

		$stmt->bind_param("iiiiii", $this->id_partida, $this->nivel_actual, $this->checkpoint, $this->monedas, $this->enemigos_derrotados, $this->jefe_derrotado);
		if ($stmt->execute()) {
			return true;
		}
		return false;
	}

	function actualizar()
	{
		$stmt = $this->conn->prepare("
		    UPDATE " . $this->tabla . " 
			SET id_partida = ?, nivel_actual = ?, checkpoint = ?, monedas = ?, enemigos_derrotados = ?, jefe_derrotado = ? 
			WHERE id_progreso = ?");

		$this->id_partida = strip_tags($this->id_partida);
		$this->nivel_actual = strip_tags($this->nivel_actual);
		$this->checkpoint = strip_tags($this->checkpoint);
		$this->monedas = strip_tags($this->monedas);
		$this->enemigos_derrotados = strip_tags($this->enemigos_derrotados);
		$this->jefe_derrotado = strip_tags($this->jefe_derrotado);
		$this->id_progreso = strip_tags($this->id_progreso);

		$stmt->bind_param("iiiiiii", $this->id_partida, $this->nivel_actual, $this->checkpoint, $this->monedas, $this->enemigos_derrotados, $this->jefe_derrotado, $this->id_progreso);

		if ($stmt->execute()) {
			return true;
		}

		return false;
	}

	function borrar()
	{
		$stmt = $this->conn->prepare("
			DELETE FROM " . $this->tabla . " 
			WHERE id_progreso = ?");

		$this->id_progreso = strip_tags($this->id_progreso);
		$stmt->bind_param("i", $this->id_progreso);
		if ($stmt->execute()) {
			return true;
		}

		return false;
	}
}
?>