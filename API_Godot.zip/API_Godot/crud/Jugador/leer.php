<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

include_once '../../basedatos/GodotGame.php';
include_once '../../tablas/Jugador.php';

//A) Se crea conexión y objeto jugador
$database = new GodotGame();
$conex = $database->dameConexion();
$jugador = new Jugador($conex);

//B) Se establecen criterios de búsqueda
//Si es un número buscará ese id, si lo encuentra muestra el jugador, si no, informará que NO lo ha encontrado
//Si no le pasamos la variable id, o no tiene valor (?id=) devolverá -1 y lo mostrará todo
if (isset($_GET['id']))
    $jugador->id_jugador = $_GET['id'];
else
    $jugador->id_jugador = -1; //Mostrará todo

$result = $jugador->leer();//Mostrará o bien el id buscado o bien todo

//C) Se leen los datos devueltos y se guardan en un array
if ($result->num_rows > 0) {
    if ($result->num_rows == 1)
        $unSoloJugador = true;

    $listaJugadores = array();  
    while ($jugadorData = $result->fetch_assoc()) { //Crea un array asociativo con cada jugador	
        extract($jugadorData); //Exporta las variables de un array
        $datosExtraidos = array(
            "id_jugador" => $id_jugador,
            "nombre" => $nombre
        );
        array_push($listaJugadores, $datosExtraidos); //Hace un append al final de la lista 
    }
    //D) Se envía respuesta y se envían los datos codificados
    http_response_code(200);
    if ($unSoloJugador)
        echo json_encode($datosExtraidos);
    else
        echo json_encode($listaJugadores);
} else { //E) En caso de no recibir datos, informa
    http_response_code(404);
    echo json_encode(
        array("info" => "No se encontraron jugadores")
    );
}
?>