<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type");

include_once '../../basedatos/GodotGame.php';
include_once '../../tablas/Partida.php';

//A) Se crea conexión y objeto partida
$database = new GodotGame();
$db = $database->dameConexion();
$partida = new Partida($db);

//B) Se decodifican los datos de entrada vía JSON
$datos = json_decode(file_get_contents("php://input"));

//C) Se comprueba que le pasamos las variables correctamente
if (isset($datos->id_partida) && isset($datos->id_jugador)) {    

    //D) Se rellena el objeto partida con datos 
    $partida->id_partida = $datos->id_partida;
    $partida->id_jugador = $datos->id_jugador;

    if ($partida->actualizar()) {//E)Llamamos a la base de datos
        //F) Se envía respuesta y se envían los datos codificados
        http_response_code(200);
        echo json_encode(array("info" => "Partida actualizada"));
    } else {
        http_response_code(503);
        echo json_encode(array("info" => "No se ha podido actualizar la partida"));
    }

} else {//G) En caso de no recibir datos, informa
    http_response_code(400);
    echo json_encode(array("info" => "No se ha podido actualizar. Datos incompletos."));
}
?>