<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type");

include_once '../../basedatos/GodotGame.php';
include_once '../../tablas/Partida.php';

//A) Se crea conexión y objeto partida
$database = new GodotGame();
$conex = $database->dameConexion();
$partida = new Partida($conex);

//B) Se decodifican los datos de entrada vía JSON
$datos = json_decode(file_get_contents("php://input"));

//C) Se comprueba que le pasamos las variables correctamente
if (isset($datos->id_jugador)) {

    //D) Se rellena el objeto partida con datos salvo el id
    $partida->id_jugador = $datos->id_jugador;

    //E) Llamamos a la base de datos
    if ($partida->insertar()) {
        //F) Se envía respuesta y se envían los datos codificados
        http_response_code(201);
        echo json_encode(array("info" => "Partida creada!"));
    } else {
        http_response_code(503);
        echo json_encode(array("info" => "No se puede crear la partida"));
    }
} else { //G) En caso de no recibir datos, informa
    http_response_code(400);
    echo json_encode(array("info" => "No se puede crear, falta el id_jugador!"));
}
?>