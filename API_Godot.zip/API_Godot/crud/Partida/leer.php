<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

include_once '../../basedatos/GodotGame.php';
include_once '../../tablas/Partida.php';

//A) Se crea conexión y objeto partida
$database = new GodotGame();
$conex = $database->dameConexion();
$partida = new Partida($conex);

//B) Se establecen criterios de búsqueda
//EJ: LEER POR ID
//Si es un número buscará ese id, si lo encuentra muestra la partida, si no, informará que NO lo ha encontrado
//Si no le pasamos la variable id, o no tiene valor (?id=) devolverá -1 y lo mostrará todo
if (isset($_GET['id']))
    $partida->id_partida = $_GET['id'];
else
    $partida->id_partida = -1; //Mostrará todo

$result = $partida->leer();//Mostrará o bien el id buscado o bien todo

//OTRA POSIBLE FUNCIONALIDAD: LEER POR JUGADOR
if (isset($_GET['id_jugador'])) {
    $partida->id_jugador = $_GET['id_jugador'];
    $result = $partida->leerPorJugador();
}
//Tal cual está montado no contempla el uso de ambas a la vez

//C) Se leen los datos devueltos y se guardan en un array
if ($result->num_rows > 0) {
    if ($result->num_rows == 1)
        $unaSolaPartida = true;

    $listaPartidas = array();  
    while ($partidaData = $result->fetch_assoc()) { //Crea un array asociativo con cada partida	
        extract($partidaData); //Exporta las variables de un array
        $datosExtraidos = array(
            "id_partida" => $id_partida,
            "id_jugador" => $id_jugador,
            "fecha_creacion" => $fecha_creacion,
            "fecha_guardado" => $fecha_guardado
        );
        array_push($listaPartidas, $datosExtraidos); //Hace un append al final de la lista 
    }
    //D) Se envía respuesta y se envían los datos codificados
    http_response_code(200);
    if ($unaSolaPartida)
        echo json_encode($datosExtraidos);
    else
        echo json_encode($listaPartidas);
} else { //E) En caso de no recibir datos, informa
    http_response_code(404);
    echo json_encode(
        array("info" => "No se encontraron partidas")
    );
}
?>