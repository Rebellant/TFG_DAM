<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type");

include_once '../../basedatos/GodotGame.php';
include_once '../../tablas/ProgresoPartida.php';

//A) Se crea conexión y objeto progreso
$database = new GodotGame();
$conex = $database->dameConexion();
$progreso = new ProgresoPartida($conex);

//B) Se decodifican los datos de entrada vía JSON
$datos = json_decode(file_get_contents("php://input"));

//C) Se comprueba que le pasamos las variables correctamente
if (isset($datos->id_partida) && isset($datos->nivel_actual) && isset($datos->monedas)) {

    //D) Se rellena el objeto progreso con datos salvo el id
    $progreso->id_partida = $datos->id_partida;
    $progreso->nivel_actual = $datos->nivel_actual;
    $progreso->checkpoint = isset($datos->checkpoint) ? $datos->checkpoint : null;
    $progreso->monedas = $datos->monedas;
    $progreso->enemigos_derrotados = isset($datos->enemigos_derrotados) ? $datos->enemigos_derrotados : 0;
    $progreso->jefe_derrotado = isset($datos->jefe_derrotado) ? $datos->jefe_derrotado : 0;

    //E) Llamamos a la base de datos
    if ($progreso->insertar()) {
        //F) Se envía respuesta y se envían los datos codificados
        http_response_code(201);
        echo json_encode(array("info" => "Progreso de partida creado!"));
    } else {
        http_response_code(503);
        echo json_encode(array("info" => "No se puede crear el progreso"));
    }
} else { //G) En caso de no recibir datos, informa
    http_response_code(400);
    echo json_encode(array("info" => "No se puede crear, faltan datos obligatorios (id_partida, nivel_actual, monedas)!"));
}
?>