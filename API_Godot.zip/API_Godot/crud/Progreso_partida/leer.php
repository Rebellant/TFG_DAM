<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

include_once '../../basedatos/GodotGame.php';
include_once '../../tablas/ProgresoPartida.php';

//A) Se crea conexión y objeto progreso
$database = new GodotGame();
$conex = $database->dameConexion();
$progreso = new ProgresoPartida($conex);

//B) Se establecen criterios de búsqueda
//EJ: LEER POR ID
//Si es un número buscará ese id, si lo encuentra muestra el progreso, si no, informará que NO lo ha encontrado
//Si no le pasamos la variable id, o no tiene valor (?id=) devolverá -1 y lo mostrará todo
if (isset($_GET['id']))
    $progreso->id_progreso = $_GET['id'];
else
    $progreso->id_progreso = -1; //Mostrará todo

$result = $progreso->leer();//Mostrará o bien el id buscado o bien todo

//OTRA POSIBLE FUNCIONALIDAD: LEER POR PARTIDA
if (isset($_GET['id_partida'])) {
    $progreso->id_partida = $_GET['id_partida'];
    $result = $progreso->leerPorPartida();
}
//Tal cual está montado no contempla el uso de ambas a la vez

//C) Se leen los datos devueltos y se guardan en un array
if ($result->num_rows > 0) {
    if ($result->num_rows == 1)
        $unSoloProgreso = true;

    $listaProgresos = array();  
    while ($progresoData = $result->fetch_assoc()) { //Crea un array asociativo con cada progreso	
        extract($progresoData); //Exporta las variables de un array
        $datosExtraidos = array(
            "id_progreso" => $id_progreso,
            "id_partida" => $id_partida,
            "nivel_actual" => $nivel_actual,
            "checkpoint" => $checkpoint,
            "monedas" => $monedas,
            "enemigos_derrotados" => $enemigos_derrotados,
            "jefe_derrotado" => $jefe_derrotado
        );
        array_push($listaProgresos, $datosExtraidos); //Hace un append al final de la lista 
    }
    //D) Se envía respuesta y se envían los datos codificados
    http_response_code(200);
    if ($unSoloProgreso)
        echo json_encode($datosExtraidos);
    else
        echo json_encode($listaProgresos);
} else { //E) En caso de no recibir datos, informa
    http_response_code(404);
    echo json_encode(
        array("info" => "No se encontraron datos de progreso")
    );
}
?>