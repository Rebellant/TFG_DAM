<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type");

include_once '../../basedatos/GodotGame.php';
include_once '../../tablas/ProgresoPartida.php';

//A) Se crea conexión y objeto progreso
$database = new GodotGame();
$db = $database->dameConexion();
$progreso = new ProgresoPartida($db);

//B) Se decodifican los datos de entrada vía JSON
$datos = json_decode(file_get_contents("php://input"));

//C) Se comprueba que le pasamos las variables correctamente
if (isset($datos->id_progreso) && isset($datos->id_partida) && isset($datos->nivel_actual) && isset($datos->monedas)) {    

    //D) Se rellena el objeto progreso con datos 
    $progreso->id_progreso = $datos->id_progreso;
    $progreso->id_partida = $datos->id_partida;
    $progreso->nivel_actual = $datos->nivel_actual;
    $progreso->checkpoint = isset($datos->checkpoint) ? $datos->checkpoint : null;
    $progreso->monedas = $datos->monedas;
    $progreso->enemigos_derrotados = isset($datos->enemigos_derrotados) ? $datos->enemigos_derrotados : 0;
    $progreso->jefe_derrotado = isset($datos->jefe_derrotado) ? $datos->jefe_derrotado : 0;

    if ($progreso->actualizar()) {//E)Llamamos a la base de datos
        //F) Se envía respuesta y se envían los datos codificados
        http_response_code(200);
        echo json_encode(array("info" => "Progreso de partida actualizado"));
    } else {
        http_response_code(503);
        echo json_encode(array("info" => "No se ha podido actualizar el progreso"));
    }

} else {//G) En caso de no recibir datos, informa
    http_response_code(400);
    echo json_encode(array("info" => "No se ha podido actualizar. Datos incompletos."));
}
?>